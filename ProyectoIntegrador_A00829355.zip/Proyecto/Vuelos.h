#ifndef Vuelos_h
#define Vuelos_h

#include "Avion.h"
#include "Fecha.h"


class Vuelos
{
private:
    Fecha fecha;
    string matricula;
    string aerolinea;
    string destino;
    string accion;
    int pasajeros;
public:
    Vuelos();
    Vuelos(string matricula, string aerolinea, string destino, string accion, int pasajeros);
    void setMatricula(string matricula);
    void setAerolinea(string aerolinea);
    void setDestino(string destino);
    void setAccion(string accion);
    void setPasajeros(int pasajeros);
    string getMatricula();
    string getAerolinea();
    string getDestino();
    string getAccion();
    int getPasajeros();
};

Vuelos::Vuelos()
{
    matricula = "AA-1234";
    aerolinea = "Aerolinea";
    destino = "destino";
    accion = "Entrada o salida";
    pasajeros = 0;
}

Vuelos::Vuelos(string matricula, string aerolinea, string destino, string accion, int pasajeros)
{
    this->matricula=matricula;
    this->aerolinea=aerolinea;
    this->destino=destino;
    this->accion=accion;
    this->pasajeros=pasajeros;
}

void Vuelos::setMatricula(string matricula)
{
    this->matricula=matricula;
}

void Vuelos::setAerolinea(string aerolinea)
{
    this->aerolinea=aerolinea;
}

void Vuelos::setDestino(string destino)
{
    this->destino=destino;
}

void Vuelos::setAccion(string accion)
{
    this->accion=accion;
}

void Vuelos::setPasajeros(int pasajeros)
{
    this->pasajeros=pasajeros;
}

string Vuelos::getMatricula()
{
    return matricula;
}

string Vuelos::getAerolinea()
{
    return aerolinea;
}

string Vuelos::getDestino()
{
    return destino;
}

string Vuelos::getAccion()
{
    return accion;
}

int Vuelos::getPasajeros()
{
    return pasajeros;
}

#endif