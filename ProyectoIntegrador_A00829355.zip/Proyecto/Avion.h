#ifndef Avion_h
#define Avion_h


class Avion
{
private:
    string avion;
    int capacidad;
public:
    Avion();
    Avion(string avion, int capacidad);
    void setAvion(string avion);
    void setCapacidad(int capacidad);
    string getAvion();
    int getCapacidad();
};

Avion::Avion()
{
    avion = "Avion default";
    capacidad = 0;
}

Avion::Avion(string avion, int capacidad)
{
    this->avion=avion;
    this->capacidad=capacidad;
}

void Avion::setAvion(string avion)
{
    this->avion=avion;
}

void Avion::setCapacidad(int capacidad)
{
    this->capacidad=capacidad;
}

string Avion::getAvion()
{
    return avion;
}

int Avion::getCapacidad()
{
    return capacidad;
}

#endif