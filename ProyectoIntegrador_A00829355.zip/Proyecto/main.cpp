#include <iostream>
#include <string>
#include <fstream>

using namespace std;

#include "Fecha.h"
#include "Avion.h"
#include "Vuelos.h"

Fecha FechaHora(string fecha_str, string hora_str) {
    int ano,mes,dia,hora,minuto;
    ano = stoi(fecha_str.substr(0,4));
    mes = stoi(fecha_str.substr(5,7));
    dia = stoi(fecha_str.substr(8,10));
    hora = stoi(hora_str.substr(0,2));
    minuto = stoi(hora_str.substr(3,5));
    Fecha f(dia,mes,ano,hora,minuto);
    return f;
}

int main(){
    ifstream archive;
    string datos[5000][4];
    int renglon = 0;
    int horas[24];
    string aerolinea;
    string destino;
    int capacidad;
    Avion aviones[5000];
    string nombre;
    int pasajeros;
    int cant_aviones = 0;
    double n = 0;
    double n2 = 0;

    for (int & hora : horas) {
        hora=0;
    }

    archive.open("datos_vuelos.txt");
    while (archive >> datos[renglon][0] >> datos[renglon][1] >> datos[renglon][2] >> datos[renglon][3] >> aerolinea >> destino >> nombre >> pasajeros >> capacidad) {
        renglon++;
        Avion avion_o(nombre,pasajeros);
        aviones[cant_aviones] = avion_o;
        cant_aviones++;

    }
    for (int i=0; i<renglon; i++){
        for (int j=0; j<6; j++) {

        }
        Fecha f = FechaHora(datos[i][0],datos[i][1]);
        Fecha (datos[i][0],datos[i][1]);
        horas[f.getHora()] += 1;
        FechaHora(datos[i][0],datos[i][1]);
    }
    for (int i=0; i<cant_aviones; i++){
        n += pasajeros;
        n2 += capacidad;
    }
    double porcentaje;
    porcentaje = (n/n2)*100;
    int mayor = 0;
    int hora = 0;
    for (int i=0;i<24;i++) {
        if (horas[i] > mayor) {
            hora = i;
            mayor = horas[i];
        }
    }

    int cont_hora0 = 0;
    int cont_hora0_salidas = 0;
    int cont_hora0_entradas = 0;
    for (int i=0;i<2540;i++)
    {
        if (datos[i][1].substr(0,2)=="00"){
            cont_hora0 = cont_hora0 + 1;
            if (datos[i][3]=="S"){
                cont_hora0_salidas = cont_hora0_salidas + 1;
            }else if (datos[i][3]=="A"){
                cont_hora0_entradas = cont_hora0_entradas + 1;
            }
        }
        
    }

    int cont_hora1 = 0;
    int cont_hora1_salidas = 0;
    int cont_hora1_entradas = 0;
    for (int i=0;i<2540;i++)
    {
        if (datos[i][1].substr(0,2)=="01"){
            cont_hora1 = cont_hora1 + 1;
            if (datos[i][3]=="S"){
                cont_hora1_salidas = cont_hora1_salidas + 1;
            }else if (datos[i][3]=="A"){
                cont_hora1_entradas = cont_hora1_entradas + 1;
            }
        }
        
    }

    int cont_hora2 = 0;
    int cont_hora2_salidas = 0;
    int cont_hora2_entradas = 0;
    for (int i=0;i<2540;i++)
    {
        if (datos[i][1].substr(0,2)=="02"){
            cont_hora2 = cont_hora2 + 1;
            if (datos[i][3]=="S"){
                cont_hora2_salidas = cont_hora2_salidas + 1;
            }else if (datos[i][3]=="A"){
                cont_hora2_entradas = cont_hora2_entradas + 1;
            }
        }
        
    }

    int cont_hora3 = 0;
    int cont_hora3_salidas = 0;
    int cont_hora3_entradas = 0;
    for (int i=0;i<2540;i++)
    {
        if (datos[i][1].substr(0,2)=="03"){
            cont_hora3 = cont_hora3 + 1;
            if (datos[i][3]=="S"){
                cont_hora3_salidas = cont_hora3_salidas + 1;
            }else if (datos[i][3]=="A"){
                cont_hora3_entradas = cont_hora3_entradas + 1;
            }
        }
        
    }

    int cont_hora4 = 0;
    int cont_hora4_salidas = 0;
    int cont_hora4_entradas = 0;
    for (int i=0;i<2540;i++)
    {
        if (datos[i][1].substr(0,2)=="04"){
            cont_hora4 = cont_hora4 + 1;
            if (datos[i][3]=="S"){
                cont_hora4_salidas = cont_hora4_salidas + 1;
            }else if (datos[i][3]=="A"){
                cont_hora4_entradas = cont_hora4_entradas + 1;
            }
        }
        
    }

    int cont_hora5 = 0;
    int cont_hora5_salidas = 0;
    int cont_hora5_entradas = 0;
    for (int i=0;i<2540;i++)
    {
        if (datos[i][1].substr(0,2)=="05"){
            cont_hora5 = cont_hora5 + 1;
            if (datos[i][3]=="S"){
                cont_hora5_salidas = cont_hora5_salidas + 1;
            }else if (datos[i][3]=="A"){
                cont_hora5_entradas = cont_hora5_entradas + 1;
            }
        }
        
    }

    int cont_hora6 = 0;
    int cont_hora6_salidas = 0;
    int cont_hora6_entradas = 0;
    for (int i=0;i<2540;i++)
    {
        if (datos[i][1].substr(0,2)=="06"){
            cont_hora6 = cont_hora6 + 1;
            if (datos[i][3]=="S"){
                cont_hora6_salidas = cont_hora6_salidas + 1;
            }else if (datos[i][3]=="A"){
                cont_hora6_entradas = cont_hora6_entradas + 1;
            }
        }
        
    }

    int cont_hora7 = 0;
    int cont_hora7_salidas = 0;
    int cont_hora7_entradas = 0;
    for (int i=0;i<2540;i++)
    {
        if (datos[i][1].substr(0,2)=="07"){
            cont_hora7 = cont_hora7 + 1;
            if (datos[i][3]=="S"){
                cont_hora7_salidas = cont_hora7_salidas + 1;
            }else if (datos[i][3]=="A"){
                cont_hora7_entradas = cont_hora7_entradas + 1;
            }
        }
        
    }

    int cont_hora8 = 0;
    int cont_hora8_salidas = 0;
    int cont_hora8_entradas = 0;
    for (int i=0;i<2540;i++)
    {
        if (datos[i][1].substr(0,2)=="08"){
            cont_hora8 = cont_hora8 + 1;
            if (datos[i][3]=="S"){
                cont_hora8_salidas = cont_hora8_salidas + 1;
            }else if (datos[i][3]=="A"){
                cont_hora8_entradas = cont_hora8_entradas + 1;
            }
        }
        
    }

    int cont_hora9 = 0;
    int cont_hora9_salidas = 0;
    int cont_hora9_entradas = 0;
    for (int i=0;i<2540;i++)
    {
        if (datos[i][1].substr(0,2)=="09"){
            cont_hora9 = cont_hora9 + 1;
            if (datos[i][3]=="S"){
                cont_hora9_salidas = cont_hora9_salidas + 1;
            }else if (datos[i][3]=="A"){
                cont_hora9_entradas = cont_hora9_entradas + 1;
            }
        }
        
    }

    int cont_hora10 = 0;
    int cont_hora10_salidas = 0;
    int cont_hora10_entradas = 0;
    for (int i=0;i<2540;i++)
    {
        if (datos[i][1].substr(0,2)=="10"){
            cont_hora10 = cont_hora10 + 1;
            if (datos[i][3]=="S"){
                cont_hora10_salidas = cont_hora10_salidas + 1;
            }else if (datos[i][3]=="A"){
                cont_hora10_entradas = cont_hora10_entradas + 1;
            }
        }
        
    }

    int cont_hora11 = 0;
    int cont_hora11_salidas = 0;
    int cont_hora11_entradas = 0;
    for (int i=0;i<2540;i++)
    {
        if (datos[i][1].substr(0,2)=="11"){
            cont_hora11 = cont_hora11 + 1;
            if (datos[i][3]=="S"){
                cont_hora11_salidas = cont_hora11_salidas + 1;
            }else if (datos[i][3]=="A"){
                cont_hora11_entradas = cont_hora11_entradas + 1;
            }
        }
        
    }

    int cont_hora12 = 0;
    int cont_hora12_salidas = 0;
    int cont_hora12_entradas = 0;
    for (int i=0;i<2540;i++)
    {
        if (datos[i][1].substr(0,2)=="12"){
            cont_hora12 = cont_hora12 + 1;
            if (datos[i][3]=="S"){
                cont_hora12_salidas = cont_hora12_salidas + 1;
            }else if (datos[i][3]=="A"){
                cont_hora12_entradas = cont_hora12_entradas + 1;
            }
        }
        
    }

    int cont_hora13 = 0;
    int cont_hora13_salidas = 0;
    int cont_hora13_entradas = 0;
    for (int i=0;i<2540;i++)
    {
        if (datos[i][1].substr(0,2)=="13"){
            cont_hora13 = cont_hora13 + 1;
            if (datos[i][3]=="S"){
                cont_hora13_salidas = cont_hora13_salidas + 1;
            }else if (datos[i][3]=="A"){
                cont_hora13_entradas = cont_hora13_entradas + 1;
            }
        }
        
    }

    int cont_hora14 = 0;
    int cont_hora14_salidas = 0;
    int cont_hora14_entradas = 0;
    for (int i=0;i<2540;i++)
    {
        if (datos[i][1].substr(0,2)=="14"){
            cont_hora14 = cont_hora14 + 1;
            if (datos[i][3]=="S"){
                cont_hora14_salidas = cont_hora14_salidas + 1;
            }else if (datos[i][3]=="A"){
                cont_hora14_entradas = cont_hora14_entradas + 1;
            }
        }
        
    }

    int cont_hora15 = 0;
    int cont_hora15_salidas = 0;
    int cont_hora15_entradas = 0;
    for (int i=0;i<2540;i++)
    {
        if (datos[i][1].substr(0,2)=="15"){
            cont_hora15 = cont_hora15 + 1;
            if (datos[i][3]=="S"){
                cont_hora15_salidas = cont_hora15_salidas + 1;
            }else if (datos[i][3]=="A"){
                cont_hora15_entradas = cont_hora15_entradas + 1;
            }
        }
        
    }

    int cont_hora16 = 0;
    int cont_hora16_salidas = 0;
    int cont_hora16_entradas = 0;
    for (int i=0;i<2540;i++)
    {
        if (datos[i][1].substr(0,2)=="16"){
            cont_hora16 = cont_hora16 + 1;
            if (datos[i][3]=="S"){
                cont_hora16_salidas = cont_hora16_salidas + 1;
            }else if (datos[i][3]=="A"){
                cont_hora16_entradas = cont_hora16_entradas + 1;
            }
        }
        
    }

    int cont_hora17 = 0;
    int cont_hora17_salidas = 0;
    int cont_hora17_entradas = 0;
    for (int i=0;i<2540;i++)
    {
        if (datos[i][1].substr(0,2)=="17"){
            cont_hora17 = cont_hora17 + 1;
            if (datos[i][3]=="S"){
                cont_hora17_salidas = cont_hora17_salidas + 1;
            }else if (datos[i][3]=="A"){
                cont_hora17_entradas = cont_hora17_entradas + 1;
            }
        }
        
    }

    int cont_hora18 = 0;
    int cont_hora18_salidas = 0;
    int cont_hora18_entradas = 0;
    for (int i=0;i<2540;i++)
    {
        if (datos[i][1].substr(0,2)=="18"){
            cont_hora18 = cont_hora18 + 1;
            if (datos[i][3]=="S"){
                cont_hora18_salidas = cont_hora18_salidas + 1;
            }else if (datos[i][3]=="A"){
                cont_hora18_entradas = cont_hora18_entradas + 1;
            }
        }
        
    }

    int cont_hora19 = 0;
    int cont_hora19_salidas = 0;
    int cont_hora19_entradas = 0;
    for (int i=0;i<2540;i++)
    {
        if (datos[i][1].substr(0,2)=="19"){
            cont_hora19 = cont_hora19 + 1;
            if (datos[i][3]=="S"){
                cont_hora19_salidas = cont_hora19_salidas + 1;
            }else if (datos[i][3]=="A"){
                cont_hora19_entradas = cont_hora19_entradas + 1;
            }
        }
        
    }

    int cont_hora20 = 0;
    int cont_hora20_salidas = 0;
    int cont_hora20_entradas = 0;
    for (int i=0;i<2540;i++)
    {
        if (datos[i][1].substr(0,2)=="20"){
            cont_hora20 = cont_hora20 + 1;
            if (datos[i][3]=="S"){
                cont_hora20_salidas = cont_hora20_salidas + 1;
            }else if (datos[i][3]=="A"){
                cont_hora20_entradas = cont_hora20_entradas + 1;
            }
        }
        
    }

    int cont_hora21 = 0;
    int cont_hora21_salidas = 0;
    int cont_hora21_entradas = 0;
    for (int i=0;i<2540;i++)
    {
        if (datos[i][1].substr(0,2)=="21"){
            cont_hora21 = cont_hora21 + 1;
            if (datos[i][3]=="S"){
                cont_hora21_salidas = cont_hora21_salidas + 1;
            }else if (datos[i][3]=="A"){
                cont_hora21_entradas = cont_hora21_entradas + 1;
            }
        }
        
    }

    int cont_hora22 = 0;
    int cont_hora22_salidas = 0;
    int cont_hora22_entradas = 0;
    for (int i=0;i<2540;i++)
    {
        if (datos[i][1].substr(0,2)=="22"){
            cont_hora22 = cont_hora22 + 1;
            if (datos[i][3]=="S"){
                cont_hora22_salidas = cont_hora22_salidas + 1;
            }else if (datos[i][3]=="A"){
                cont_hora22_entradas = cont_hora22_entradas + 1;
            }
        }
        
    }

    int cont_hora23 = 0;
    int cont_hora23_salidas = 0;
    int cont_hora23_entradas = 0;
    for (int i=0;i<2540;i++)
    {
        if (datos[i][1].substr(0,2)=="23"){
            cont_hora23 = cont_hora23 + 1;
            if (datos[i][3]=="S"){
                cont_hora23_salidas = cont_hora23_salidas + 1;
            }else if (datos[i][3]=="A"){
                cont_hora23_entradas = cont_hora23_entradas + 1;
            }
        }
        
    }

    int cont_hora24 = 0;
    int cont_hora24_salidas = 0;
    int cont_hora24_entradas = 0;
    for (int i=0;i<2540;i++)
    {
        if (datos[i][1].substr(0,2)=="24"){
            cont_hora24 = cont_hora24 + 1;
            if (datos[i][3]=="S"){
                cont_hora24_salidas = cont_hora24_salidas + 1;
            }else if (datos[i][3]=="A"){
                cont_hora24_entradas = cont_hora24_entradas + 1;
            }
        }
        
    }

    int salidas_hora0_promedio = cont_hora0_salidas/2;
    int entradas_hora0_promedio = cont_hora0_entradas/2;

    int salidas_hora1_promedio = cont_hora1_salidas/2;
    int entradas_hora1_promedio = cont_hora1_entradas/2;

    int salidas_hora2_promedio = cont_hora2_salidas/2;
    int entradas_hora2_promedio = cont_hora2_entradas/2;

    int salidas_hora3_promedio = cont_hora3_salidas/2;
    int entradas_hora3_promedio = cont_hora3_entradas/2;

    int salidas_hora4_promedio = cont_hora4_salidas/2;
    int entradas_hora4_promedio = cont_hora4_entradas/2;

    int salidas_hora5_promedio = cont_hora5_salidas/2;
    int entradas_hora5_promedio = cont_hora5_entradas/2;

    int salidas_hora6_promedio = cont_hora6_salidas/2;
    int entradas_hora6_promedio = cont_hora6_entradas/2;
    
    int salidas_hora7_promedio = cont_hora7_salidas/2;
    int entradas_hora7_promedio = cont_hora7_entradas/2;

    int salidas_hora8_promedio = cont_hora8_salidas/2;
    int entradas_hora8_promedio = cont_hora8_entradas/2;

    int salidas_hora9_promedio = cont_hora9_salidas/2;
    int entradas_hora9_promedio = cont_hora9_entradas/2;

    int salidas_hora10_promedio = cont_hora10_salidas/2;
    int entradas_hora10_promedio = cont_hora10_entradas/2;

    int salidas_hora11_promedio = cont_hora11_salidas/2;
    int entradas_hora11_promedio = cont_hora11_entradas/2;

    int salidas_hora12_promedio = cont_hora12_salidas/2;
    int entradas_hora12_promedio = cont_hora12_entradas/2;

    int salidas_hora13_promedio = cont_hora13_salidas/2;
    int entradas_hora13_promedio = cont_hora13_entradas/2;

    int salidas_hora14_promedio = cont_hora14_salidas/2;
    int entradas_hora14_promedio = cont_hora14_entradas/2;

    int salidas_hora15_promedio = cont_hora15_salidas/2;
    int entradas_hora15_promedio = cont_hora15_entradas/2;

    int salidas_hora16_promedio = cont_hora16_salidas/2;
    int entradas_hora16_promedio = cont_hora16_entradas/2;

    int salidas_hora17_promedio = cont_hora17_salidas/2;
    int entradas_hora17_promedio = cont_hora17_entradas/2;

    int salidas_hora18_promedio = cont_hora18_salidas/2;
    int entradas_hora18_promedio = cont_hora18_entradas/2;

    int salidas_hora19_promedio = cont_hora19_salidas/2;
    int entradas_hora19_promedio = cont_hora19_entradas/2;

    int salidas_hora20_promedio = cont_hora20_salidas/2;
    int entradas_hora20_promedio = cont_hora20_entradas/2;

    int salidas_hora21_promedio = cont_hora21_salidas/2;
    int entradas_hora21_promedio = cont_hora21_entradas/2;

    int salidas_hora22_promedio = cont_hora22_salidas/2;
    int entradas_hora22_promedio = cont_hora22_entradas/2;

    int salidas_hora23_promedio = cont_hora23_salidas/2;
    int entradas_hora23_promedio = cont_hora23_entradas/2;

    int salidas_hora24_promedio = cont_hora24_salidas/2;
    int entradas_hora24_promedio = cont_hora24_entradas/2;

    cout << "La hora mas saturada es: " << hora << "horas con " << mayor << " vuelos" << endl;
    cout << "Hora 0 - " << salidas_hora0_promedio << " salidas y " << entradas_hora0_promedio << " entradas promedio" << endl;
    cout << "Hora 1 - " << salidas_hora1_promedio << " salidas y " << entradas_hora1_promedio << " entradas promedio" << endl;
    cout << "Hora 2 - " << salidas_hora2_promedio << " salidas y " << entradas_hora2_promedio << " entradas promedio" << endl;
    cout << "Hora 3 - " << salidas_hora3_promedio << " salidas y " << entradas_hora3_promedio << " entradas promedio" << endl;
    cout << "Hora 4 - " << salidas_hora4_promedio << " salidas y " << entradas_hora4_promedio << " entradas promedio" << endl;
    cout << "Hora 5 - " << salidas_hora5_promedio << " salidas y " << entradas_hora5_promedio << " entradas promedio" << endl;
    cout << "Hora 6 - " << salidas_hora6_promedio << " salidas y " << entradas_hora6_promedio << " entradas promedio" << endl;
    cout << "Hora 7 - " << salidas_hora7_promedio << " salidas y " << entradas_hora7_promedio << " entradas promedio" << endl;
    cout << "Hora 8 - " << salidas_hora8_promedio << " salidas y " << entradas_hora8_promedio << " entradas promedio" << endl;
    cout << "Hora 9 - " << salidas_hora9_promedio << " salidas y " << entradas_hora9_promedio << " entradas promedio" << endl;
    cout << "Hora 10 - " << salidas_hora10_promedio << " salidas y " << entradas_hora10_promedio << " entradas promedio" << endl;
    cout << "Hora 11 - " << salidas_hora11_promedio << " salidas y " << entradas_hora11_promedio << " entradas promedio" << endl;
    cout << "Hora 12 - " << salidas_hora12_promedio << " salidas y " << entradas_hora12_promedio << " entradas promedio" << endl;
    cout << "Hora 13 - " << salidas_hora13_promedio << " salidas y " << entradas_hora13_promedio << " entradas promedio" << endl;
    cout << "Hora 14 - " << salidas_hora14_promedio << " salidas y " << entradas_hora14_promedio << " entradas promedio" << endl;
    cout << "Hora 15 - " << salidas_hora15_promedio << " salidas y " << entradas_hora15_promedio << " entradas promedio" << endl;
    cout << "Hora 16 - " << salidas_hora16_promedio << " salidas y " << entradas_hora16_promedio << " entradas promedio" << endl;
    cout << "Hora 17 - " << salidas_hora17_promedio << " salidas y " << entradas_hora17_promedio << " entradas promedio" << endl;
    cout << "Hora 18 - " << salidas_hora18_promedio << " salidas y " << entradas_hora18_promedio << " entradas promedio" << endl;
    cout << "Hora 19 - " << salidas_hora19_promedio << " salidas y " << entradas_hora19_promedio << " entradas promedio" << endl;
    cout << "Hora 20 - " << salidas_hora20_promedio << " salidas y " << entradas_hora20_promedio << " entradas promedio" << endl;
    cout << "Hora 21 - " << salidas_hora21_promedio << " salidas y " << entradas_hora21_promedio << " entradas promedio" << endl;
    cout << "Hora 22 - " << salidas_hora22_promedio << " salidas y " << entradas_hora22_promedio << " entradas promedio" << endl;
    cout << "Hora 23 - " << salidas_hora23_promedio << " salidas y " << entradas_hora23_promedio << " entradas promedio" << endl;
    cout << "Hora 24 - " << salidas_hora24_promedio << " salidas y " << entradas_hora24_promedio << " entradas promedio" << endl;
    cout << "Hubo " << n << " pasajeros en el dia" << endl;
    cout << "La capacidad en porcentaje del dia fue de: " << porcentaje << "%" << endl;
    archive.close();


    return 0;
}